

module.exports = {
    host: 'localhost',
    database: 'vidjot',
    username: 'itp211',
    password: 'itp211'
    }